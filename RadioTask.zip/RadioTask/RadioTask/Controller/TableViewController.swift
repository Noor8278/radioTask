//
//  TableViewController.swift
//  RadioTask
//
//  Created by brn.developers on 11/22/18.
//  Copyright © 2018 Noor. All rights reserved.
//


import UIKit

import AVKit

import AVFoundation



var nameArray = [String]()

var tagArray = [String]()

var imagesArray = [UIImage]()

var songArray = [String]()





class TableViewController: UITableViewController {
    
    
    
    var URLSessionObj: URLSession!
    
    var URLReqObj: URLRequest!
    
    var loginDataTask: URLSessionDataTask!
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        
        self.serverdata()
        
        
        
        var customCell = UINib(nibName: "TableViewCell", bundle: nil)
        
        tableView.register(customCell, forCellReuseIdentifier: "cell")
        
        
        
        
        
    }
    
    func serverdata(){
        
        let parameters = "lastcount=0"
        
        
        
        guard let url = URL(string: "https://www.radio-browser.info/webservice/json/stations/bycountry/india") else { return }
        
        var request = URLRequest(url: url)
        
        
        
        request.httpBody = parameters.data(using: .utf8, allowLossyConversion: true)
        
        request.httpMethod = "POST"
        
        
        
        let session = URLSession.shared
        
        session.dataTask(with: request) { (data, response, error) in
            
            
            
            if let jsondata = data {
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: jsondata, options: .allowFragments) as! [[String:Any]]
                    
                    print(json.count)
                    
                    for i in 0...12
                        
                    {
                        
                        var some =  (json[i]["name"]!)
                        
                        var some1 =  (json[i]["tags"]!)
                        
                        var images = (json[i]["favicon"]!)
                        
                        var song =   (json[i]["url"]!)
                        
                        
                        
                        let str = (self.description as! String).replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
                        
                        nameArray.append(some as! String)
                        
                        tagArray.append(some1 as! String)
                        
                        songArray.append(song as! String )
                        
                        
                        
                        do{
                            
                            let url = URL(string: images as! String)
                            
                            let data = try Data(contentsOf: url!)
                            
                            imagesArray.append(UIImage(data: data)!)
                            
                        }
                        
                        
                        
                    }
                    
                    
                    
                    DispatchQueue.main.sync {
                        
                        self.tableView.delegate = self
                        
                        self.tableView.dataSource = self
                        
                        self.tableView.reloadData()
                        
                    }
                    
                    
                    
                    
                    
                } catch {
                    
                    print(error)
                    
                }
                
            }
            
            
            
            }.resume()
        
        
        
    }
    
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        // #warning Incomplete implementation, return the number of sections
        
        return 1
        
    }
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nameArray.count
        
        
        
    }
    
    
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        cell.titleDesc.text = nameArray[indexPath.row]
        
        cell.dateDisplay.text = tagArray[indexPath.row]
        
        cell.myImage.image = imagesArray[indexPath.row]
        
        
        
        
        
        return cell
        
    }
    
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        
        
        return 166
        
    }
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        let songUrl = songArray[indexPath.row]
        
        let videoURL = URL(string: songUrl)
        
        let player = AVPlayer(url: videoURL!)
        
        let playerViewController = AVPlayerViewController()
        
        playerViewController.player = player
        
        self.present(playerViewController, animated: true) {
            
            playerViewController.player!.play()
            
        }
        
        
        
    }
    
    
    
}
