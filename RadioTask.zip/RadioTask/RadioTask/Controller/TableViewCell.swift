//
//  TableViewCell.swift
//  RadioTask
//
//  Created by brn.developers on 11/22/18.
//  Copyright © 2018 Noor. All rights reserved.
//

import UIKit



class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var titleDesc: UILabel!
    
    @IBOutlet weak var dateDisplay: UILabel!
    
    

    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        
        // Initialization code
        
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        
        super.setSelected(selected, animated: animated)
        
        
        
        // Configure the view for the selected state
        
    }
    
    
    
}
